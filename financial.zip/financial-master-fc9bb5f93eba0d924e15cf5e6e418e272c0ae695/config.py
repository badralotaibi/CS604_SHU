#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os


DEBUG = True
BASE_DIR = os.path.abspath(os.path.dirname(__file__))

CSRF_ENABLED = True
SECRET_KEY = '-pzdsv$cuc!$1!_@#38)&rt!-bt+z9-z9!#3th+sn$mhz__)@j'

AUTH_SERVICE_URL = 'http://localhost:5001/auth/%s'
